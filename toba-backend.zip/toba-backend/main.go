package main

import (
	"fmt"
	"os"
	"strings"
	"time"

	"toba-backend/config"
	"toba-backend/database"
	"toba-backend/routes"
	"toba-backend/websocket"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/limiter"
	"github.com/gofiber/fiber/v2/middleware/logger"
)

func main() {
	// ============================================================
	// DATABASE
	// ============================================================
	config.ConnectDatabase()

	// Seed tidak lagi dijalankan otomatis setiap server start.
	// Ini mencegah perubahan konten soal Admin tertimpa/nonaktif saat restart.
	// Jalankan seed secara sengaja ketika bank soal final sudah siap:
	// TOBA_RUN_SEED=true
	if strings.EqualFold(strings.TrimSpace(os.Getenv("TOBA_RUN_SEED")), "true") {
		database.SeedAll()
	} else {
		fmt.Println("ℹ️ Seed otomatis dilewati. Set TOBA_RUN_SEED=true hanya saat memang ingin menjalankan seed.")
	}

	// ============================================================
	// WEBSOCKET HUB
	// ============================================================
	go websocket.Hub.Run()

	app := fiber.New(fiber.Config{
		AppName:        "TOBA API v1.0",
		ReadBufferSize: 8192,
	})

	app.Use(logger.New())

	app.Use(cors.New(cors.Config{
		AllowOrigins: "http://localhost:5173, http://127.0.0.1:5173",
		AllowHeaders: "Origin, Content-Type, Accept, Authorization",
		AllowMethods: "GET, POST, PUT, DELETE, OPTIONS",
	}))

	api := app.Group("/api")

	api.Use(limiter.New(limiter.Config{
		Max:        60,
		Expiration: 1 * time.Minute,
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(
				fiber.Map{"message": "Terlalu banyak permintaan. Coba lagi sebentar."},
			)
		},
	}))

	authLimiter := limiter.New(limiter.Config{
		Max:        5,
		Expiration: 1 * time.Minute,
		LimitReached: func(c *fiber.Ctx) error {
			return c.Status(fiber.StatusTooManyRequests).JSON(
				fiber.Map{"message": "Terlalu banyak percobaan login. Tunggu 1 menit."},
			)
		},
	})

	routes.RegisterRoutes(app, api, authLimiter)

	fmt.Println()
	fmt.Println("========================================")
	fmt.Println("   TOBA SERVER AKTIF DI PORT 8080")
	fmt.Println("   WebSocket: ws://localhost:8080/ws/")
	fmt.Println("   API Rate Limit: 60 request/menit/IP")
	fmt.Println("   Auth Rate Limit: 5 request/menit/IP")
	fmt.Println("   Player Protected Routes: AKTIF")
	fmt.Println("   Admin Protected Routes: AKTIF")
	fmt.Println("========================================")
	fmt.Println()

	if err := app.Listen("0.0.0.0:8080"); err != nil {
		fmt.Println("Server gagal dijalankan:", err)
	}
}
