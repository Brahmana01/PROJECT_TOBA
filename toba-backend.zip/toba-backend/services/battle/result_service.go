package battle

import (
	"errors"
	"time"

	"toba-backend/config"
	"toba-backend/models"
	playerprogression "toba-backend/services/player"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

const (
	BattleWinnerRewardXP    = 50
	BattleWinnerRewardStars = 2
)

type FinishBattleResult struct {
	Status        string `json:"status"`
	HostScore     int64  `json:"host_score"`
	GuestScore    int64  `json:"guest_score"`
	WinnerID      *uint  `json:"winner_id"`
	RewardXP      int    `json:"reward_xp"`
	RewardStars   int    `json:"reward_stars"`
	PreviousLevel int    `json:"previous_level"`
	Level         int    `json:"level"`
	LeveledUp     bool   `json:"leveled_up"`
	TotalXP       int    `json:"total_xp"`
	TotalStars    int    `json:"total_stars"`
	XPForNext     int    `json:"xp_for_next"`
	XPProgress    int    `json:"xp_progress"`
}

func countCorrectAnswers(tx *gorm.DB, roomID uint, playerID uint) (int64, error) {
	var count int64
	err := tx.Model(&models.BattleAnswer{}).
		Where("room_id = ? AND player_id = ? AND is_correct = ?", roomID, playerID, true).
		Count(&count).Error
	return count, err
}

func awardBattleWinner(tx *gorm.DB, winnerID uint) (*playerprogression.ProgressionResult, error) {
	var winner models.Player
	if err := tx.
		Clauses(clause.Locking{Strength: "UPDATE"}).
		First(&winner, winnerID).Error; err != nil {
		return nil, err
	}

	return playerprogression.ApplyRewardToLockedPlayer(
		tx,
		&winner,
		BattleWinnerRewardXP,
		BattleWinnerRewardStars,
	)
}

func FinishBattle(
	roomID uint,
	playerID uint,
) (*FinishBattleResult, string, int) {

	var response FinishBattleResult
	var responseStatus int

	if roomID == 0 || playerID == 0 {
		return nil, "Data room atau pemain tidak valid", 400
	}

	err := config.DB.Transaction(func(tx *gorm.DB) error {
		var room models.BattleRoom

		if err := tx.
			Clauses(clause.Locking{Strength: "UPDATE"}).
			First(&room, roomID).Error; err != nil {
			return err
		}

		// Pastikan pemanggil merupakan peserta room.
		isHost := room.HostPlayerID == playerID
		isGuest := room.GuestPlayerID != nil &&
			*room.GuestPlayerID == playerID

		if !isHost && !isGuest {
			responseStatus = 403
			return errors.New("player bukan peserta battle")
		}

		// Request berulang tidak boleh memberikan reward kedua kali.
		if room.Status == "FINISHED" {
			hostScore, err := countCorrectAnswers(
				tx,
				room.ID,
				room.HostPlayerID,
			)
			if err != nil {
				return err
			}

			var guestScore int64

			if room.GuestPlayerID != nil {
				guestScore, err = countCorrectAnswers(
					tx,
					room.ID,
					*room.GuestPlayerID,
				)
				if err != nil {
					return err
				}
			}

			response = FinishBattleResult{
				Status:     room.Status,
				HostScore:  hostScore,
				GuestScore: guestScore,
				WinnerID:   room.WinnerPlayerID,
			}

			responseStatus = 200
			return nil
		}

		if room.Status != "PLAYING" {
			responseStatus = 400
			return errors.New("battle belum berlangsung atau tidak dapat diselesaikan")
		}

		if room.GuestPlayerID == nil {
			responseStatus = 400
			return errors.New("peserta kedua belum bergabung")
		}

		// Pastikan pertandingan memiliki lima soal.
		var assignedQuestionCount int64

		if err := tx.Model(&models.BattleRoomQuestion{}).
			Where("room_id = ?", room.ID).
			Count(&assignedQuestionCount).Error; err != nil {
			return err
		}

		if assignedQuestionCount != models.BattleQuestionCount {
			responseStatus = 400
			return errors.New("jumlah soal battle tidak sesuai")
		}

		hostScore, err := countCorrectAnswers(
			tx,
			room.ID,
			room.HostPlayerID,
		)
		if err != nil {
			return err
		}

		guestScore, err := countCorrectAnswers(
			tx,
			room.ID,
			*room.GuestPlayerID,
		)
		if err != nil {
			return err
		}

		var winnerID *uint

		if hostScore > guestScore {
			winnerID = &room.HostPlayerID
		} else if guestScore > hostScore {
			winnerID = room.GuestPlayerID
		}

		finishedAt := time.Now()

		room.Status = "FINISHED"
		room.WinnerPlayerID = winnerID
		room.FinishedAt = &finishedAt

		if err := tx.Save(&room).Error; err != nil {
			return err
		}

		response = FinishBattleResult{
			Status:     room.Status,
			HostScore:  hostScore,
			GuestScore: guestScore,
			WinnerID:   winnerID,
		}

		// Reward hanya diberikan kepada pemenang.
		if winnerID != nil {
			progression, err := awardBattleWinner(
				tx,
				*winnerID,
			)
			if err != nil {
				return err
			}

			response.RewardXP = progression.RewardXP
			response.RewardStars = progression.RewardStars
			response.PreviousLevel = progression.PreviousLevel
			response.Level = progression.Level
			response.LeveledUp = progression.LeveledUp
			response.TotalXP = progression.TotalXP
			response.TotalStars = progression.TotalStars
			response.XPForNext = progression.XPForNext
			response.XPProgress = progression.XPProgress
		}

		responseStatus = 200
		return nil
	})

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return nil, "Room tidak ditemukan", 404
		}

		if responseStatus == 403 || responseStatus == 400 {
			return nil, err.Error(), responseStatus
		}

		return nil, "Gagal menyelesaikan battle atau memberikan reward", 500
	}

	return &response, "", responseStatus
}

func DisconnectBattle(roomID uint, playerID uint) (uint, string, int) {
	var winnerID uint
	responseMessage := ""
	responseStatus := 400

	err := config.DB.Transaction(func(tx *gorm.DB) error {
		var room models.BattleRoom
		if err := tx.
			Clauses(clause.Locking{Strength: "UPDATE"}).
			First(&room, roomID).Error; err != nil {
			return err
		}

		if room.Status != "PLAYING" {
			responseMessage = "Battle tidak sedang berlangsung"
			return nil
		}

		if room.HostPlayerID == playerID {
			if room.GuestPlayerID == nil {
				responseMessage = "Tidak ada lawan"
				return nil
			}
			winnerID = *room.GuestPlayerID
		} else if room.GuestPlayerID != nil && *room.GuestPlayerID == playerID {
			winnerID = room.HostPlayerID
		} else {
			responseMessage = "Player bukan peserta battle"
			responseStatus = 403
			return nil
		}

		finishedAt := time.Now()
		room.Status = "FINISHED"
		room.WinnerPlayerID = &winnerID
		room.FinishedAt = &finishedAt

		if err := tx.Save(&room).Error; err != nil {
			return err
		}

		if _, err := awardBattleWinner(tx, winnerID); err != nil {
			return err
		}

		return nil
	})

	if err != nil {
		if errors.Is(err, gorm.ErrRecordNotFound) {
			return 0, "Room tidak ditemukan", 404
		}
		return 0, "Gagal menyelesaikan battle atau memberikan reward", 500
	}
	if responseMessage != "" {
		return 0, responseMessage, responseStatus
	}

	return winnerID, "", 200
}
