package battle

import (
	"time"

	"toba-backend/config"
	"toba-backend/models"
)

func SubmitBattleAnswer(
	roomID uint,
	playerID uint,
	questionID uint,
	selectedOptionID uint,
	answerTimeMs int64,
) (bool, string, int) {

	if answerTimeMs < 200 || answerTimeMs > 16000 {
		return false, "Waktu jawaban tidak valid", 400
	}

	var room models.BattleRoom

	if err := config.DB.First(&room, roomID).Error; err != nil {
		return false, "Room tidak ditemukan", 404
	}

	if room.Status != "PLAYING" {
		return false, "Battle tidak sedang berlangsung", 400
	}

	if room.HostPlayerID != playerID &&
		(room.GuestPlayerID == nil || *room.GuestPlayerID != playerID) {
		return false, "Player bukan peserta battle", 403
	}

	var roomQuestion models.BattleRoomQuestion

	if err := config.DB.
		Where("room_id = ? AND question_id = ?", roomID, questionID).
		First(&roomQuestion).Error; err !
package battle

import (
	"errors"
	"time"

	"toba-backend/config"
	"toba-backend/models"

	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

func SubmitBattleAnswer(
	roomID uint,
	playerID uint,
	questionID uint,
	selectedOptionID uint,
	answerTimeMs int64,
) (bool, string, int) {

	if roomID == 0 || playerID == 0 ||
		questionID == 0 || selectedOptionID == 0 {
		return false, "Data jawaban tidak lengkap", 400
	}

	if answerTimeMs < 200 || answerTimeMs > 16000 {
		return false, "Waktu jawaban tidak valid", 400
	}

	var isCorrect bool
	var businessStatus int
	var businessMessage string

	err := config.DB.Transaction(func(tx *gorm.DB) error {

		// Mengunci room agar dua request jawaban bersamaan
		// tidak membuat jawaban ganda untuk pemain yang sama.
		var room models.BattleRoom

		if err := tx.
			Clauses(clause.Locking{Strength: "UPDATE"}).
			First(&room, roomID).Error; err != nil {
			return err
		}

		if room.Status != "PLAYING" {
			businessStatus = 400
			businessMessage = "Battle tidak sedang berlangsung"
			return errors.New(businessMessage)
		}

		isParticipant := room.HostPlayerID == playerID ||
			(room.GuestPlayerID != nil &&
				*room.GuestPlayerID == playerID)

		if !isParticipant {
			businessStatus = 403
			businessMessage = "Player bukan peserta battle"
			return errors.New(businessMessage)
		}

		var roomQuestion models.BattleRoomQuestion

		if err := tx.
			Where(
				"room_id = ? AND question_id = ?",
				roomID,
				questionID,
			).
			First(&roomQuestion).Error; err != nil {
			businessStatus = 400
			businessMessage = "Pertanyaan bukan bagian dari battle"
			return errors.New(businessMessage)
		}

		// Periksa apakah pertanyaan sudah dijawab.
		var existing models.BattleAnswer

		existingErr := tx.
			Where(
				"room_id = ? AND player_id = ? AND question_id = ?",
				roomID,
				playerID,
				questionID,
			).
			First(&existing).Error

		if existingErr == nil {
			if existing.SelectedOptionID == selectedOptionID {
				// Retry request dengan jawaban sama tidak memberikan
				// efek tambahan.
				isCorrect = existing.IsCorrect
				return nil
			}

			businessStatus = 409
			businessMessage = "Pertanyaan sudah pernah dijawab"
			return errors.New(businessMessage)
		}

		if !errors.Is(existingErr, gorm.ErrRecordNotFound) {
			return existingErr
		}

		// Pastikan opsi memang milik pertanyaan ini.
		var option models.BattleQuestionOption

		if err := tx.
			Where(
				"id = ? AND question_id = ?",
				selectedOptionID,
				questionID,
			).
			First(&option).Error; err != nil {
			businessStatus = 400
			businessMessage = "Pilihan jawaban bukan milik pertanyaan"
			return errors.New(businessMessage)
		}

		answer := models.BattleAnswer{
			RoomID:           roomID,
			PlayerID:         playerID,
			QuestionID:       questionID,
			SelectedOptionID: selectedOptionID,
			IsCorrect:        option.IsCorrect,
			AnsweredAt:       time.Now(),
		}

		if err := tx.Create(&answer).Error; err != nil {
			return err
		}

		isCorrect = option.IsCorrect
		return nil
	})

	if err != nil {
		if businessStatus != 0 {
			return false, businessMessage, businessStatus
		}

		if errors.Is(err, gorm.ErrRecordNotFound) {
			return false, "Room tidak ditemukan", 404
		}

		return false, "Gagal menyimpan jawaban", 500
	}

	return isCorrect, "", 200
}
= nil {
		return false, "Pertanyaan bukan bagian dari battle", 400
	}

	var option models.BattleQuestionOption

	if err := config.DB.First(&option, selectedOptionID).Error; err != nil {
		return false, "Pilihan jawaban tidak ditemukan", 400
	}

	answer := models.BattleAnswer{
		RoomID:           roomID,
		PlayerID:         playerID,
		QuestionID:       questionID,
		SelectedOptionID: selectedOptionID,
		IsCorrect:        option.IsCorrect,
		AnsweredAt:       time.Now(),
	}

	if err := config.DB.Create(&answer).Error; err != nil {
		return false, "Gagal menyimpan jawaban", 500
	}

	return option.IsCorrect, "", 200
}
